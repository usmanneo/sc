## BACA DULU BANG

> **Warning**: Sc nya gk support termux. [`Klik disini untuk download sc yg support termux`](https://github.com/zeeoneofficial/Haruka-Md#For-Termux)

-----------------------------------------------------

<p align="center">
<img src="https://github.com/zeeoneofficial/Haruka-Md/blob/v1/media/Haruka.jpg" alt="ALPHA BOT" width="100"/>


</p>
<p align="center">
<a href="#"><img title="HARUKA MULTI DEVICE" src="https://img.shields.io/badge/HARUKA MULTI DEVICE-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/zeeoneofficial/Haruka-Md"><img title="Owner" src="https://img.shields.io/badge/Recode-ZeeoneOfc-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/zeeoneofficial/followers"><img title="Followers" src="https://img.shields.io/github/followers/zeeoneofficial?color=red&style=flat-square"></a>
<a href="https://github.com/zeeoneofficial/Haruka-Md/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/zeeoneofficial/Haruka-Md?color=blue&style=flat-square"></a>
<a href="https://github.com/zeeoneofficial/Haruka-Md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/zeeoneofficial/Haruka-Md?color=red&style=flat-square"></a>
<a href="https://github.com/zeeoneofficial/Haruka-Md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/zeeoneofficial/Haruka-Md?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/zeeoneofficial/Haruka-Md"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/zeeoneofficial/Haruka-Md/"><img title="Size" src="https://img.shields.io/github/repo-size/zeeoneofficial/Haruka-Md?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fzeeoneofficial%2FHaruka-Md&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/zeeoneofficial/Haruka-Md/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>

<p align="center">
  <a href="https://github.com/zeeoneofficial/Haruka-Md#Edit-Owner">Settings</a> •
  <a href="https://github.com/zeeoneofficial/Haruka-Md#instalasi">Installation</a> •
  <a href="https://github.com/zeeoneofficial/Haruka-Md#thanks-to">Thanks to</a> •
  <a href="https://github.com/zeeoneofficial/Haruka-Md#Official-Group"> Official Group Bot</a> •
  <a href="https://github.com/zeeoneofficial/Haruka-Md#donate">Donate</a>
</p>
</div>


---

# Instalasi
## HEROKU BUILDPACK

```
> heroku/nodejs
> https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
> https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

--------

## FOR HEROKU USER 

[![Deploy on Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/login)

[`Click Here For Tutorial`](https://youtu.be/2grMt0TbfOM)<br>

----------
<p align="center">
  <a href="https://youtu.be/2grMt0TbfOM"><img src="https://telegra.ph/file/dd32f9b493adc7a6ea33f.jpg" />
</p>
<br>

----------
## FOR RAILWAY USER 

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app?referralCode=zeeoneofc)

[`Click Here For Tutorial`](https://youtu.be/BqRauxohbLg)<br>

----------

<p align="center">
  <a href="https://youtu.be/BqRauxohbLg"><img src="https://telegra.ph/file/ba58c4ad1b43bc285f16b.jpg" />
</p>
<br>

----------
## FOR OKTETO USER 
[![Deploy on Okteto](https://okteto.com/develop-okteto.svg)](https://cloud.okteto.com/deploy)

[`Click Here For Tutorial`](https://youtu.be/FhHl_hvnY2s)

----------

<p align="center">
  <a href="https://youtu.be/FhHl_hvnY2s"><img src="https://telegra.ph/file/e5f7eac9d4272b869eb69.jpg" />
</p>
<br>

----------
## FOR REPLIT USER
[![Run on Repl.it](https://repl.it/badge/github/zeeoneofficial/Alphabot-Md)](https://repl.it/github/zeeoneofficial/Alphabot-Md)
------
<p align="center">
  <a href="https://youtu.be/jom_scHK09c"><img src="https://telegra.ph/file/873e2bbfbd1f15a535995.jpg" />
</p>
<br>

----------
## FOR PANEL USER 

[`Click Here For Tutorial`](https://youtu.be/H2BZ3KFvQys)

----------

<p align="center">
  <a href="https://youtu.be/H2BZ3KFvQys"><img src="https://telegra.ph/file/d2ab9876306da1e9c55d5.jpg" />
</p>
<br>

----------

## FOR DOPRAX USER 

[![Deploy on doprax](https://www.linkpicture.com/q/doprax-zeeoneofc.my.id.svg)](https://www.doprax.com/r/zeeoneofc/)

[`Tutorial soon`](https://youtu.be/BqRauxohbLg)<br>

----------

<!-- <p align="center">
  <a href="https://youtu.be/BqRauxohbLg"><img src="https://telegra.ph/file/ba58c4ad1b43bc285f16b.jpg" />
</p> -->

## For Termux
- [Download script MediaFire](https://youtu.be/WcJ6f24AvR8)

<p align="center">
<a href="https://youtu.be/WcJ6f24AvR8"><img src="https://telegra.ph/file/b4e608b6a4d1053a7df65.jpg" />
</p>

## Edit Owner 

<details>
    <summary> <b>Edit Owner Config.json</b></summary><br/>

```ts
{
    "ownerNumber": ["6281250431837@s.whatsapp.net","6283137133540@s.whatsapp.net"],
    "ownerName": "Kyami-MD",
    "instagram" : "https://instagram.com/kyamicuy",
    "botName": "GawrGura V2",
    "footer": "api.zeeoneofc.xyz",
    "sessionName": "session",
    "pathimg": "./media/Gura.jpg",
    "BotKey": "Gsyt6jRJ",
    "auto_welcomeMsg": true,
    "auto_leaveMsg": true,    
    "autobio": true,
    "anticall": true,
    "autorespond": false,
    "autoblok212": true,
    "autoread": true,
    "gamewaktu": 90,
    "limitCount": 25,
    "gcount": {
        "prem": 1000,
        "user": 15
    }
}
```

## Donate
- [Saweria](https://saweria.co/zeeoneofc)
- [Dana](https://j.top4top.io/p_20532posd1.jpg)
- [Ovo](https://h.top4top.io/p_2053vk0uw1.jpg)

# Official Group
- [Group 1](https://chat.whatsapp.com/EU890BcXjyBDkNaUT5WmYV)
- [Group 2](https://chat.whatsapp.com/E8NExJwIbhBJYzssfqJNsE)
- [Group 3](https://chat.whatsapp.com/KCSqHTky1apG7ApePsfiPy)
- [Group 4](https://chat.whatsapp.com/KwmvHr7VMFj7r5ry9xmMsU)
- [Group 5](https://chat.whatsapp.com/ELa7GhU0sP4EvXcVimQYtz)

